/// @file
/// @ingroup gvc_api
/*************************************************************************
 * Copyright (c) 2011 AT&T Intellectual Property 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html
 *
 * Contributors: Details at https://graphviz.org
 *************************************************************************/

/* Header used by plugins */

#pragma once

#include "gvplugin.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void gvconfig_plugin_install_from_library(GVC_t * gvc,
                                                 char *package_path,
                                                 gvplugin_library_t *library);

#ifdef __cplusplus
}
#endif
