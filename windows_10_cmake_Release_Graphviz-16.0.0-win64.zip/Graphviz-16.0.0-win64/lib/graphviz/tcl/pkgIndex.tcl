package ifneeded Tcldot 16.0.0 "
	load [file join $dir libtcldot.dll] Tcldot"
package ifneeded Tclpathplan 16.0.0 "
	load [file join $dir libtclplan.dll] Tclpathplan"
package ifneeded Gdtclft 16.0.0 "
	load [file join $dir libgdtclft.dll] Gdtclft"
# end
